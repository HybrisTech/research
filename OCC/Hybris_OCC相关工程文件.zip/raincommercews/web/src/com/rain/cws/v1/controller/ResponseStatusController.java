/**
 *
 */
package com.rain.cws.v1.controller;

import org.apache.log4j.Logger;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rain.cws.data.WSResponseStatusData;


/**
 *
 *
 * @author 鲍传琦
 * @time 2015年4月28日 下午1:15:49
 * @since JDK 1.7
 */

@Controller("responseStatusControllerV1")
public class ResponseStatusController extends BaseController
{
	private final static Logger LOG = Logger.getLogger(ResponseStatusController.class);

	@Secured("ROLE_CSSN_WS")
	@RequestMapping(value = "/{baseSiteId}/wsresp", method = RequestMethod.POST)
	@ResponseBody
	public WSResponseStatusData wsResponseStatus()
	{
		LOG.info("---------------wsResponseStatus-------------");
		final WSResponseStatusData wsResponseStatus = new WSResponseStatusData();
		wsResponseStatus.setCode("001");
		wsResponseStatus.setStatus("SUCCESS");
		return wsResponseStatus;
	}
}
