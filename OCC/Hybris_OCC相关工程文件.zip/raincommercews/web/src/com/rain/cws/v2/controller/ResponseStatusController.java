/**
 *
 */
package com.rain.cws.v2.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rain.cws.CSTestData.CSTestDataFacade;
import com.rain.cws.data.CSTestDataList;
import com.rain.cws.data.WSResponseStatusData;
import com.rain.cws.populator.CSTestData.CWSCSTestDataListPopulate;


/**
 *
 *
 * @author 鲍传琦
 * @time 2015年4月28日 下午1:15:49
 * @since JDK 1.7
 */

@Controller
public class ResponseStatusController extends BaseController
{
	private final static Logger LOG = Logger.getLogger(ResponseStatusController.class);

	@Resource(name = "cwsCSTestDataListPopulate")
	private CWSCSTestDataListPopulate cwsCSTestDataListPopulate;

	@Resource(name = "csTestDataFacade")
	private CSTestDataFacade csTestDataFacade;


	@Secured(
	{ "ROLE_CUSTOMERGROUP", "ROLE_CSSN_WS" })
	@RequestMapping(value = "/{baseSiteId}/wsresp", method = RequestMethod.POST)
	@ResponseBody
	public WSResponseStatusData wsResponseStatus(final HttpServletRequest request)
	{
		LOG.info("---------------wsResponseStatus-------------");
		final CSTestDataList csTestDataList = new CSTestDataList();
		cwsCSTestDataListPopulate.populate(request, csTestDataList);
		LOG.info("num=" + csTestDataList.getCSTestDatas().size());
		final Boolean flag = csTestDataFacade.createOrUpdateCSTestData(csTestDataList);
		final WSResponseStatusData wsResponseStatus = new WSResponseStatusData();
		if (flag)
		{

			wsResponseStatus.setCode("001");
			wsResponseStatus.setStatus("SUCCESS");
		}
		else
		{
			wsResponseStatus.setCode("002");
			wsResponseStatus.setStatus("FAILED");
		}
		return wsResponseStatus;
	}
}
