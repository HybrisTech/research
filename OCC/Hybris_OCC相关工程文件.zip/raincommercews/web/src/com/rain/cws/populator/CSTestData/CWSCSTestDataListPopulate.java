/**
 *
 */
package com.rain.cws.populator.CSTestData;

import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.google.gson.Gson;
import com.rain.cws.data.CSTestData;
import com.rain.cws.data.CSTestDataList;
import com.rain.cws.populator.AbstractHttpRequestDataPopulator;


/**
 *
 *
 * @author 鲍传琦
 * @time 2015年4月29日 下午3:41:27
 * @since JDK 1.7
 */

@Component("cwsCSTestDataListPopulate")
@Scope("prototype")
public class CWSCSTestDataListPopulate extends AbstractHttpRequestDataPopulator implements
		Populator<HttpServletRequest, CSTestDataList>
{
	private static final String CSTESTDATAS = "CSTestDatas";

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.hybris.platform.converters.Populator#populate(java.lang.Object, java.lang.Object)
	 */
	@Override
	public void populate(final HttpServletRequest request, final CSTestDataList csTestDataList) throws ConversionException
	{
		Assert.notNull(request, "Parameter request cannot be null.");
		Assert.notNull(csTestDataList, "Parameter csTestDataList cannot be null.");

		csTestDataList.setCSTestDatas(getCSTestDataFromRequest(request));
	}

	private List<CSTestData> getCSTestDataFromRequest(final HttpServletRequest request)
	{
		final String allReault = getRequestParameterValue(request, CSTESTDATAS);
		final Gson gson = new Gson();
		final CSTestDataList csdatas = gson.fromJson(allReault, CSTestDataList.class);
		return csdatas.getCSTestDatas();
	}

}
