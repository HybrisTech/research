/**
 *
 */
package com.rain.cws.CSTestData.impl;

import com.rain.core.dao.CSTestDataDAO;
import com.rain.core.model.CSTestDataModel;
import com.rain.cws.CSTestData.CSTestDataFacade;
import com.rain.cws.data.CSTestData;
import com.rain.cws.data.CSTestDataList;


/**
 *
 *
 * @author 鲍传琦
 * @time 2015年4月29日 下午4:42:31
 * @since JDK 1.7
 */
public class DefaultCSTestDataFacade implements CSTestDataFacade
{
	private CSTestDataDAO csTestDataDAO;

	@Override
	public Boolean createOrUpdateCSTestData(final CSTestDataList csTestDatas)
	{
		for (final CSTestData cd : csTestDatas.getCSTestDatas())
		{
			CSTestDataModel csTestDataModel = csTestDataDAO.getCsTestDataModelByCode(cd.getCode());
			if (csTestDataModel == null)
			{
				csTestDataModel = new CSTestDataModel();
			}
			csTestDataDAO.saveCSTestData(cd, csTestDataModel);
		}
		return Boolean.TRUE;
	}

	/**
	 * @param csTestDataDAO
	 *           the csTestDataDAO to set
	 */
	public void setCsTestDataDAO(final CSTestDataDAO csTestDataDAO)
	{
		this.csTestDataDAO = csTestDataDAO;
	}

}
