/**
 *
 */
package com.rain.cws.CSTestData;

import com.rain.cws.data.CSTestDataList;


/**
 *
 *
 * @author 鲍传琦
 * @time 2015年4月29日 下午4:41:51
 * @since JDK 1.7
 */
public interface CSTestDataFacade
{
	public Boolean createOrUpdateCSTestData(CSTestDataList csTestDatas);
}
