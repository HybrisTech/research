package com.ws.main;

import com.ws.pro.TokenLogin;
import com.ws.pro.WebServiceAuthProvider;
import com.ws.pro.WebServiceDataProvider;
import com.ws.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by sayrain on 15/5/29.
 */
public class HybrisOauthById {

    public static void main(final String[] args) throws IOException
    {
        /* 登录获取access_token */
        String oauth="";
        Map<String, String> loginBody=new HashMap<String,String>();
        loginBody.put("grant_type", "client_credentials");

        oauth=WebServiceDataProvider.getLoginResponse(loginBody);
        TokenLogin tokenLogin = JsonUtils.fromJson(oauth, TokenLogin.class);
        if (tokenLogin != null && StringUtils.isNotBlank(tokenLogin.getAccess_token()))
        {
            WebServiceAuthProvider.saveTokens(tokenLogin);
        }

        String result=oauth;

        System.out.println(result);
    }

}
