package com.ws.main;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.data.beans.CSTestData;
import com.data.beans.CSTestDataList;
import com.google.gson.Gson;
import com.ws.pro.WebServiceDataProvider;
import com.ws.pro.WebServiceAuthProvider;
import com.ws.pro.TokenLogin;
import com.ws.util.JsonUtils;

/**
 * Created by sayrain on 15/4/27.
 */
public class HybrisUserResponse {

    public static void main(final String[] args) throws IOException
    {
        List<CSTestData> csTestDataList=new ArrayList<CSTestData>();
        for (int i=0;i<3;i++){
        	CSTestData cstestData=new CSTestData();
        	cstestData.setCode(""+i);
        	cstestData.setValue("124124124");
        	csTestDataList.add(cstestData);
        }
        CSTestDataList csTestDatas=new CSTestDataList();
        csTestDatas.setCSTestDatas(csTestDataList);
        Gson gson=new Gson();
        String dataResult=gson.toJson(csTestDatas, CSTestDataList.class);

        Map<String, String> httpBody=new HashMap<String,String>();
        httpBody.put("CSTestDatas", dataResult);

        String result=WebServiceDataProvider.getResponse("https://10.10.66.140:9002/rain/v2/ws/wsresp",Boolean.TRUE,"POST",httpBody);

        System.out.print(result);

    }

}
