package com.ws.main;

import com.ws.pro.OCCSetting;
import com.ws.pro.WebServiceDataProvider;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by sayrain on 15/5/29.
 */
public class HybrisClientResponse {

    public static void main(final String[] args) throws IOException
    {
        Map<String, String> httpBody=new HashMap<String,String>();
        httpBody.put("", "");
        String result= WebServiceDataProvider.getClientCredentialsResponse("https://10.10.66.140:9002/rain/v1/ws/wsresp", "POST", httpBody);
        System.out.println(result);
    }
}
