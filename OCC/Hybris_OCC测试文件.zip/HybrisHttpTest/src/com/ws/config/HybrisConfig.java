package com.ws.config;

/**
 * Created by sayrain on 15/5/26.
 */
public class HybrisConfig {

    public static String OAUTH_CLIENT="cssn_ws";

    public static String OAUTH_SECRET="secret";

    public static String OAUTH_LOGIN="cssn_ws:secret";

    public static String OAUTH_URL="https://10.10.66.140:9002/rain/oauth/token";

    public static String OAUTH_CALLBACK_URL="http://10.10.66.140:9001/rain/oauth2_callback";

    public static String BASE_URL="https://10.10.66.140:9002/rain/v2";

    public static String FOR_LOGOUT_URL="https://10.10.66.140:9002/rain/v2/customers/current/logout";

    public static String OAUTH_FILENAME="Oauthconfig.properties";

}
