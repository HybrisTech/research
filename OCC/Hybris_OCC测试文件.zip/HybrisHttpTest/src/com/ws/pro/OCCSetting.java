package com.ws.pro;
/**
 * Created by sayrain on 15/4/27.
 */

import com.ws.config.HybrisConfig;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public final class OCCSetting {

    public static final String client_id = HybrisConfig.OAUTH_CLIENT;
    public static final String client_secret = HybrisConfig.OAUTH_SECRET;

    private static final Map<String, String> settings = new HashMap<String, String>();

    public static String getSharedPreferenceString(String key)
    {
        Properties prop = new Properties();
        try{
            FileInputStream fis = new FileInputStream(HybrisConfig.OAUTH_FILENAME);
            prop.load(fis);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return prop.getProperty(key);
    }

    public static void setSharedPreferenceString(Map<String,String> config)
    {
        Properties prop = new Properties();
        for (String key:config.keySet()){
            prop.setProperty(key,config.get(key));
        }
        try{
            FileOutputStream fos = new FileOutputStream(HybrisConfig.OAUTH_FILENAME);
            prop.store(fos,"");
            fos.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    public static String getConstant(String key)
    {
        Properties prop = new Properties();
        String result="";
        try{
            FileInputStream fis = new FileInputStream(HybrisConfig.OAUTH_FILENAME);
            prop.load(fis);
            result=prop.getProperty(key);
            fis.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    public static void setSettingValue(String settingName, String value)
    {
        settings.put(settingName, value);
    }

    public static String getSettingValue(String settingName)
    {
        return settings.get(settingName);
    }


}
