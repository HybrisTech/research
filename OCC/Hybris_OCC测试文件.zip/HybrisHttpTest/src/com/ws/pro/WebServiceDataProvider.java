package com.ws.pro;
/*******************************************************************************
 * [y] hybris Platform
 *  
 *   Copyright (c) 2000-2013 hybris AG
 *   All rights reserved.
 *  
 *   This software is the confidential and proprietary information of hybris
 *   ("Confidential Information"). You shall not disclose such Confidential
 *   Information and shall use it only in accordance with the terms of the
 *   license agreement you entered into with hybris.
 ******************************************************************************/


import com.ws.config.HybrisConfig;
import it.sauronsoftware.base64.Base64;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;

import net.sf.json.JSONObject;
import net.sf.json.JSONException;


public class WebServiceDataProvider
{

	// Trust every server - don't check for any certificate
	final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier()
	{
		public boolean verify(String hostname, SSLSession session)
		{
			return true;
		}
	};

	private static void trustAllHosts()
	{
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[]
		{ new X509TrustManager()
		{
			public X509Certificate[] getAcceptedIssuers()
			{
				return new X509Certificate[] {};
			}

			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
			}

			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
			}
		} };

		// Install the all-trusting trust manager
		try
		{
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		}
		catch (Exception e)
		{
			System.out.println("Error with SSL connection. " + e.getLocalizedMessage());
		}
	}

	// Static helper methods

	private static String readFromStream(InputStream in) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		BufferedReader r = new BufferedReader(new InputStreamReader(in), 1000);
		for (String line = r.readLine(); line != null; line = r.readLine())
		{
			sb.append(line);
		}
		in.close();
		return sb.toString();
	}

	public static String encodePostBody(Map<String,String> parameters)
	{
		if (parameters == null)
		{
			return "";
		}

		StringBuilder sb = new StringBuilder();

		for (Iterator<String> i = parameters.keySet().iterator(); i.hasNext();)
		{
			String key = i.next();
			Object parameter = parameters.get(key);
			if (!(parameter instanceof String))
			{
				continue;
			}

			try
			{
				sb.append(URLEncoder.encode(key, "UTF-8"));
				sb.append("=");
				sb.append(URLEncoder.encode((String) parameter, "UTF-8"));
			}
			catch (UnsupportedEncodingException e)
			{
				// TODO report parse error
				System.out.println("Error encoding \"" + key + "\" or \"" + parameter + "\" to UTF-8 ." + e.getLocalizedMessage());
			}

			if (i.hasNext())
			{
				sb.append("&");
			}
		}
		return sb.toString();
	}

	private static String baseUrl()
	{
		return String.format(HybrisConfig.BASE_URL);
	}

	private static String urlForLogout()
	{
		return String.format(HybrisConfig.FOR_LOGOUT_URL);
	}

	public static HttpURLConnection createConnection(URL url) throws IOException
	{
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		connection.setRequestProperty("Connection", "Keep-Alive");
		return connection;
	}

	public static HttpsURLConnection createSecureConnection(URL url) throws IOException
	{
		HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		connection.setRequestProperty("Connection", "Keep-Alive");
		return connection;
	}

	private static String addParameters(String urlAsString)
	{
		String updatedUrlAsString = urlAsString;
		String spacer = "?";
		if (urlAsString.contains("?"))
		{
			spacer = "&";
		}

		return updatedUrlAsString;
	}

	/**
	 * Synchronous call to the OCC web services
	 * 
	 * @param url
	 *           The url
	 * @param isAuthorizedRequest
	 *           Whether this request requires the authorization token sending
	 * @param httpMethod
	 *           method type (GET, PUT, POST, DELETE)
	 * @param httpBody
	 *           Data to be sent in the body (Can be empty)
	 * @return The data from the server as a string, in almost all cases JSON
	 * @throws java.net.MalformedURLException
	 * @throws java.io.IOException
	 * @throws java.net.ProtocolException
	 */
	public static String getResponse(String url, Boolean isAuthorizedRequest, String httpMethod, Map<String,String> httpBody)
			throws MalformedURLException, IOException, ProtocolException
	{
		// Refresh if necessary
		if (isAuthorizedRequest && WebServiceAuthProvider.tokenExpiredHint())
		{
			WebServiceAuthProvider.refreshAccessToken();
		}

		boolean refreshLimitReached = false;
		int refreshed = 0;

		String response = "";
		while (!refreshLimitReached)
		{
			// If we have refreshed max number of times, we will not do so again
			if (refreshed == 1)
			{
				refreshLimitReached = true;
			}

			// Make the connection and get the response
			OutputStream os;
			HttpURLConnection connection;

			if (httpMethod.equals("GET") && httpBody != null && !httpBody.isEmpty())
			{
				url = url + "?" + encodePostBody(httpBody);
			}
			URL requestURL = new URL(addParameters(url));

			if (StringUtils.equalsIgnoreCase(requestURL.getProtocol(), "https"))
			{
				System.out.println("Https Request!!");
				trustAllHosts();
				HttpsURLConnection https = createSecureConnection(requestURL);
				https.setHostnameVerifier(DO_NOT_VERIFY);
				if (isAuthorizedRequest)
				{
					String authValue = "Bearer " + OCCSetting.getSharedPreferenceString("access_token");
					https.setRequestProperty("Authorization", authValue);
				}
				connection = https;
			}
			else
			{
				connection = createConnection(requestURL);
			}
			connection.setRequestMethod(httpMethod);

			if (!httpMethod.equals("GET") && !httpMethod.equals("DELETE"))
			{
				connection.setDoOutput(true);
				connection.setDoInput(true);
				connection.connect();

				if (httpBody != null && !httpBody.isEmpty())
				{
					os = new BufferedOutputStream(connection.getOutputStream());
					os.write(encodePostBody(httpBody).getBytes());
					os.flush();
				}
			}

			response = "";
			try
			{
				System.out.println(connection.toString());
				response = readFromStream(connection.getInputStream());
			}
			catch (FileNotFoundException e)
			{
				System.out.println("Error reading stream \"" + connection.getInputStream() + "\". " + e.getLocalizedMessage());
				response = readFromStream(connection.getErrorStream());
			}
			finally
			{
				connection.disconnect();
			}

			// Allow for calls to return nothing
			if (response.length() == 0)
			{
				return "";
			}

			// Check for JSON parsing errors (will throw JSONException is can't be parsed)
			JSONObject object = new JSONObject(response);

			// If no error, return response
			if (!object.has("error"))
			{
				return response;
			}
			// If there is a refresh token error, refresh the token
			else if (object.getString("error").equals("invalid_token"))
			{
				if (refreshLimitReached)
				{
					// Give up
					return response;
				}
				else
				{
					// Refresh the token
					WebServiceAuthProvider.refreshAccessToken();
					refreshed++;
				}
			}
		} // while(!refreshLimitReached)

		// There is an error other than a refresh error, so return the response
		return response;
	}

	/**
	 * Synchronous call to get a new client credentials token, required for creating new account
	 * 
	 * @param url
	 * @param httpMethod
	 * @param httpBody
	 * @return The data from the server as a string, in almost all cases JSON
	 * @throws java.net.MalformedURLException
	 * @throws java.io.IOException
	 * @throws java.net.ProtocolException
	 * @throws net.sf.json.JSONException
	 */
	public static String getClientCredentialsResponse(String url, String httpMethod, Map<String,String> httpBody) throws MalformedURLException, IOException, ProtocolException, JSONException
	{
        boolean refreshLimitReached = false;
        int refreshed = 0;

        String response = "";
        while (!refreshLimitReached)
        {
            // If we have refreshed max number of times, we will not do so again
            if (refreshed == 1)
            {
                refreshLimitReached = true;
            }

            // Make the connection and get the response
            OutputStream os;
            HttpURLConnection connection;

            if (httpMethod.equals("GET") && httpBody != null && !httpBody.isEmpty())
            {
                url = url + "?" + encodePostBody(httpBody);
            }
            URL requestURL = new URL(addParameters(url));

            if (StringUtils.equalsIgnoreCase(requestURL.getProtocol(), "https"))
            {
                System.out.println("Https Request!!");
                trustAllHosts();
                HttpsURLConnection https = createSecureConnection(requestURL);
                https.setHostnameVerifier(DO_NOT_VERIFY);

                String authValue = "Bearer " + OCCSetting.getSharedPreferenceString("access_token");
                https.setRequestProperty("Authorization", authValue);

                connection = https;
            }
            else
            {
                connection = createConnection(requestURL);
            }
            connection.setRequestMethod(httpMethod);

            if (!httpMethod.equals("GET") && !httpMethod.equals("DELETE"))
            {
                connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.connect();

                if (httpBody != null && !httpBody.isEmpty())
                {
                    os = new BufferedOutputStream(connection.getOutputStream());
                    os.write(encodePostBody(httpBody).getBytes());
                    os.flush();
                }
            }

            response = "";
            try
            {
                System.out.println(connection.toString());
                response = readFromStream(connection.getInputStream());
            }
            catch (FileNotFoundException e)
            {
                System.out.println("Error reading stream \"" + connection.getInputStream() + "\". " + e.getLocalizedMessage());
                response = readFromStream(connection.getErrorStream());
            }
            finally
            {
                connection.disconnect();
            }

            // Allow for calls to return nothing
            if (response.length() == 0)
            {
                return "";
            }

            // Check for JSON parsing errors (will throw JSONException is can't be parsed)
            JSONObject object = new JSONObject(response);

            // If no error, return response
            if (!object.has("error"))
            {
                return response;
            }
            // If there is a refresh token error, refresh the token
            else if (object.getString("error").equals("invalid_token"))
            {
                if (refreshLimitReached)
                {
                    // Give up
                    return response;
                }
                else
                {
                    // Refresh the token
                    WebServiceAuthProvider.refreshAccessToken();
                    refreshed++;
                }
            }
        } // while(!refreshLimitReached)

        // There is an error other than a refresh error, so return the response
        return response;
	}


	/**
	 * Synchronous call for logging in
	 * 
	 * @param httpBody
	 * @return The data from the server as a string, in almost all cases JSON
	 * @throws java.net.MalformedURLException
	 * @throws java.io.IOException
	 * @throws net.sf.json.JSONException
	 */
	public static String getLoginResponse(Map<String,String> httpBody) throws MalformedURLException, IOException
	{
		String response = "";
		URL url = new URL(WebServiceAuthProvider.tokenURL());
		trustAllHosts();
		HttpsURLConnection connection = createSecureConnection(url);
		connection.setHostnameVerifier(DO_NOT_VERIFY);
		String authString = HybrisConfig.OAUTH_LOGIN;
		String authValue = "Basic " + Base64.encode(authString);

		connection.setRequestMethod("POST");
		connection.setRequestProperty("Authorization", authValue);
		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.connect();

		OutputStream os = new BufferedOutputStream(connection.getOutputStream());
		os.write(encodePostBody(httpBody).getBytes());
		os.flush();
		try
		{
			System.out.println(connection.toString());
			response = readFromStream(connection.getInputStream());
		}
		catch (MalformedURLException e)
		{
			System.out.println("Error reading stream \"" + connection.getInputStream() + "\". " + e.getLocalizedMessage());
		}
		catch (IOException e)
		{
			response = readFromStream(connection.getErrorStream());
		}
		finally
		{
			connection.disconnect();
		}
		
		//WebServiceAuthProvider.saveTokens(JsonUtils.fromJson(response, TokenLogin.class));
		
		return response;
	}


	/**
	 * Synchronous call for logging out
	 * 
	 * @return The data from the server as a string, in almost all cases JSON
	 * @throws java.net.MalformedURLException
	 * @throws java.io.IOException
	 * @throws net.sf.json.JSONException
	 */
	public static String getLogoutResponse() throws MalformedURLException, IOException, JSONException
	{
		// Refresh if necessary
		if (WebServiceAuthProvider.tokenExpiredHint())
		{
			WebServiceAuthProvider.refreshAccessToken();
		}

		boolean refreshLimitReached = false;
		int refreshed = 0;

		String response = "";
		while (!refreshLimitReached)
		{
			// If we have refreshed max number of times, we will not do so again
			if (refreshed == 1)
			{
				refreshLimitReached = true;
			}


			URL url = new URL(urlForLogout());
			HttpsURLConnection connection = createSecureConnection(url);
			trustAllHosts();
			connection.setHostnameVerifier(DO_NOT_VERIFY);
			String authValue = "Bearer " + OCCSetting.getSharedPreferenceString("access_token");

			connection.setRequestMethod("POST");
			connection.setRequestProperty("Authorization", authValue);
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.connect();

			try
			{
				System.out.println("LogoutResponse" + connection.toString());
				response = readFromStream(connection.getInputStream());
			}
			catch (MalformedURLException e)
			{
				System.out.println("Error reading stream \"" + connection.getInputStream() + "\". " + e.getLocalizedMessage());
			}
			catch (IOException e)
			{
				response = readFromStream(connection.getErrorStream());
			}
			finally
			{
				connection.disconnect();
			}

			// Allow for calls to return nothing
			if (response.length() == 0)
			{
				return "";
			}

			// Check for JSON parsing errors (will throw JSONException is can't be parsed)
			JSONObject object = new JSONObject(response);

			// If no error, return response
			if (!object.has("error"))
			{
				return response;
			}
			// If there is a refresh token error, refresh the token
			else if (object.getString("error").equals("invalid_token"))
			{
				if (refreshLimitReached)
				{
					// Give up
					return response;
				}
				else
				{
					// Refresh the token
					WebServiceAuthProvider.refreshAccessToken();
					refreshed++;
				}
			}
		} // while(!refreshLimitReached)

		return response;
	}

}
