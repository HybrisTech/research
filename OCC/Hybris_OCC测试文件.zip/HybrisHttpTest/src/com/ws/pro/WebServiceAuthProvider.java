package com.ws.pro;
/*******************************************************************************
 * [y] hybris Platform
 *  
 *   Copyright (c) 2000-2013 hybris AG
 *   All rights reserved.
 *  
 *   This software is the confidential and proprietary information of hybris
 *   ("Confidential Information"). You shall not disclose such Confidential
 *   Information and shall use it only in accordance with the terms of the
 *   license agreement you entered into with hybris.
 ******************************************************************************/


import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.ws.config.HybrisConfig;
import com.ws.util.CookieUtils;
import com.ws.util.JsonUtils;


/**
 * Helper class that encapsulates the access_token refreshing and provides other auth information.
 * 
 * This class does not need to be public for users of the SDK.
 */
public class WebServiceAuthProvider
{
	private static final String LOG_TAG = WebServiceAuthProvider.class.getSimpleName();

	// Trust every server - don't check for any certificate
	final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier()
	{
		public boolean verify(String hostname, SSLSession session)
		{
			return true;
		}
	};

	private static void trustAllHosts()
	{
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[]
		{ new X509TrustManager()
		{
			public X509Certificate[] getAcceptedIssuers()
			{
				return new X509Certificate[] {};
			}

			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
			}

			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
			}
		} };

		// Install the all-trusting trust manager
		try
		{
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		}
		catch (Exception e)
		{
			//LoggingUtils.e(LOG_TAG, "Error with SSL connection. " + e.getLocalizedMessage(), null);
		}
	}

	public static String tokenURL()
	{
		return HybrisConfig.OAUTH_URL;
	}

	public static String callbackURL()
	{
		return HybrisConfig.OAUTH_CALLBACK_URL;
	}

	private static String readFromStream(InputStream in) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		BufferedReader r = new BufferedReader(new InputStreamReader(in), 1000);
		for (String line = r.readLine(); line != null; line = r.readLine())
		{
			sb.append(line);
		}
		in.close();
		return sb.toString();
	}

	public static void saveTokens(TokenLogin tokenLogin)
	{
        Map<String,String> tokenMap=new HashMap<String,String> ();
        tokenMap.put("issued_on", DateFormat.getDateTimeInstance().format(new Date()));
        tokenMap.put("expires_in", tokenLogin.getExpires_in());
        tokenMap.put("refresh_token", (tokenLogin.getRefresh_token()==null?"":tokenLogin.getRefresh_token()));
        tokenMap.put("access_token", tokenLogin.getAccess_token());

        OCCSetting.setSharedPreferenceString(tokenMap);
	}

	public static void clearTokens()
	{
        Map<String,String> tokenMap=new HashMap<String,String> ();
        tokenMap.put("issued_on", "");
        tokenMap.put("expires_in", "");
        tokenMap.put("refresh_token", "");
        tokenMap.put("access_token", "");

        OCCSetting.setSharedPreferenceString(tokenMap);

		// Clear cookies
		CookieUtils.clearCookies();
	}

	/**
	 * Returns a hint
	 * 
	 * @return
	 */
	public static boolean tokenExpiredHint()
	{
		try
		{
			long interval = new Date().getTime()
					- DateFormat.getDateTimeInstance().parse(OCCSetting.getSharedPreferenceString("issued_on")).getTime();
			long expires_in = Long.parseLong(OCCSetting.getSharedPreferenceString("expires_in"));

			return interval > expires_in;
		}
		catch (Exception e)
		{
//			LoggingUtils.e(LOG_TAG, "Error parsing date \"" + SDKSettings.getSharedPreferenceString(context, "issued_on") + "\". "
//					+ e.getLocalizedMessage(), null);
			return true;
		}
	}

	public static String encodePostBody(Map<String,String> parameters)
	{
		if (parameters == null)
		{
			return "";
		}

		StringBuilder sb = new StringBuilder();

		for (Iterator<String> i = parameters.keySet().iterator(); i.hasNext();)
		{
			String key = i.next();
			Object parameter = parameters.get(key);
			if (!(parameter instanceof String))
			{
				continue;
			}

			try
			{
				sb.append(URLEncoder.encode(key, "UTF-8"));
				sb.append("=");
				sb.append(URLEncoder.encode((String) parameter, "UTF-8"));
			}
			catch (UnsupportedEncodingException e)
			{
				// TODO report parse error
			}

			if (i.hasNext())
			{
				sb.append("&");
			}
		}

		return sb.toString();
	}


	/// Request a new refresh token based on the current tokens stored in NSUserDefaults
	static void refreshAccessToken() throws IOException
	{
		System.out.println("Auth Refreshing Access Token");
        System.out.println(tokenURL());
        trustAllHosts();
        HttpsURLConnection connection=(HttpsURLConnection) new URL(tokenURL()).openConnection();
        
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		connection.setRequestProperty("Connection", "Keep-Alive");
		connection.setHostnameVerifier(DO_NOT_VERIFY);

		// Body
		Map<String,String> postBody = new HashMap<String,String>();
		postBody.put("grant_type", "refresh_token");
		postBody.put("refresh_token", OCCSetting.getSharedPreferenceString("refresh_token"));
		postBody.put("client_id", OCCSetting.client_id);
		postBody.put("client_secret", OCCSetting.client_secret);
		postBody.put("redirect_uri", WebServiceAuthProvider.callbackURL());

		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.connect();
		OutputStream os = new BufferedOutputStream(connection.getOutputStream());
		os.write(encodePostBody(postBody).getBytes());
		os.flush();

		String response = "";
		try
		{
			response = readFromStream(connection.getInputStream());
		}
		catch (FileNotFoundException e)
		{
			response = readFromStream(connection.getErrorStream());
		}
		finally
		{
			connection.disconnect();
		}

		// Parse and set the values
		// TODO
		WebServiceAuthProvider.saveTokens(JsonUtils.fromJson(response, TokenLogin.class));
	}

}
