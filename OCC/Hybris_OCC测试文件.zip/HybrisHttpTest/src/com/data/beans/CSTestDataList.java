/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN!
 * --- Generated at 2015-4-29 17:32:06
 * ----------------------------------------------------------------
 *
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2013 hybris AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of hybris
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with hybris.
 *
 *
 */
package com.data.beans;

import com.data.beans.CSTestData;
import java.util.List;

public class CSTestDataList  implements java.io.Serializable 
{

	/** <i>Generated property</i> for <code>CSTestDataList.CSTestDatas</code> property defined at extension <code>raincommercews</code>. */
	private List<CSTestData> CSTestDatas;
		
	public CSTestDataList()
	{
		// default constructor
	}
	
		
	public void setCSTestDatas(final List<CSTestData> CSTestDatas)
	{
		this.CSTestDatas = CSTestDatas;
	}
	
		
	public List<CSTestData> getCSTestDatas() 
	{
		return CSTestDatas;
	}
		
	
}